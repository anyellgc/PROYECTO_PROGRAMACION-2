from django.urls import path
from .views import chatbot_response

urlpatterns = [
    # Al usar '' aquí, el endpoint raíz (/) lanza chatbot_response
    path('', chatbot_response, name='chatbot_response'),
]
