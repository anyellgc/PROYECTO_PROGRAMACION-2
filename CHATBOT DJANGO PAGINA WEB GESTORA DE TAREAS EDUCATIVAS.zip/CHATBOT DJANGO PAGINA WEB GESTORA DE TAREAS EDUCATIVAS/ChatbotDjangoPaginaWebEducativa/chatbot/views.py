from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

@csrf_exempt
def chatbot_response(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        user_message = data.get('message', '').lower()

        # Lógica simple de respuesta
        if 'hola' in user_message:
            response = '¡Hola! ¿Cómo puedo ayudarte con tus tareas?'
        elif 'tarea' in user_message:
            response = 'Puedes ver tus tareas en la sección "Mis tareas".'
        else:
            response = 'No entendí eso. Intenta otra vez.'

        return JsonResponse({'response': response})

    # Para peticiones GET devolvemos la plantilla de chat
    return render(request, 'chatbot/chat.html')
